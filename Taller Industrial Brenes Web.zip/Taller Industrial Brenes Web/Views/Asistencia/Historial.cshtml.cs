using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Taller_Industrial_Brenes_Web.Views.Asistencia
{
    public class HistorialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
