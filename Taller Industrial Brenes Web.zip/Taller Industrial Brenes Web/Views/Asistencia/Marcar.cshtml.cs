using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Taller_Industrial_Brenes_Web.Views.Asistencia
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
