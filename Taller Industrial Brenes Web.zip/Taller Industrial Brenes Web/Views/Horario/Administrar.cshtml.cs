using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Taller_Industrial_Brenes_Web.Views.Horario
{
    public class AdministrarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
