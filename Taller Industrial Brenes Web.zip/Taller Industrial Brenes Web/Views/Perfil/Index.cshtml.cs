using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CapaTours.Views.Perfil
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
