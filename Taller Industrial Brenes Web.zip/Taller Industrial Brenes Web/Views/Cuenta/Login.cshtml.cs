using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Taller_Industrial_Brenes_Web.Views.Cuenta
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
