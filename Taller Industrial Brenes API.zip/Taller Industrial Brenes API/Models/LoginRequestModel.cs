﻿namespace Taller_Industrial_Brenes_API.Models
{
    public class LoginRequestModel
    {
        public string Correo { get; set; }
        public string Contrasenna { get; set; }
    }
}

